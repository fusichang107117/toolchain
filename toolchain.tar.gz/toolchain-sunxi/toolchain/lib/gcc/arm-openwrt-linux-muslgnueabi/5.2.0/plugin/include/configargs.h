/* Generated automatically. */
static const char configuration_arguments[] = "/home/caiyongheng/tina_test/out/azalea-perf1/compile_dir/toolchain/gcc-5.2.0/configure --with-bugurl=https://dev.openwrt.org/ --with-pkgversion='OpenWrt GCC 5.2.0 70-1-1' --prefix=/home/caiyongheng/tina_test/out/azalea-perf1/staging_dir/toolchain --build=x86_64-linux-gnu --host=x86_64-linux-gnu --target=arm-openwrt-linux-muslgnueabi --with-gnu-ld --enable-target-optspace --disable-libgomp --disable-libmudflap --disable-multilib --disable-nls --without-isl --without-cloog --with-host-libstdcxx=-lstdc++ --with-gmp=/home/caiyongheng/tina_test/out/host --with-mpfr=/home/caiyongheng/tina_test/out/host --with-mpc=/home/caiyongheng/tina_test/out/host --disable-decimal-float --with-diagnostics-color=auto-if-env --disable-libssp --enable-__cxa_atexit --with-arch=armv7-a --with-float=hard --with-headers=/home/caiyongheng/tina_test/out/azalea-perf1/staging_dir/toolchain/include --disable-libsanitizer --enable-languages=c,c++ --enable-shared --enable-threads --with-slibdir=/home/caiyongheng/tina_test/out/azalea-perf1/staging_dir/toolchain/lib --enable-lto --with-libelf=/home/caiyongheng/tina_test/out/host";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "arch", "armv7-a" }, { "float", "hard" }, { "tls", "gnu" } };
